__version__ = '2.4'
from iCR import iCR
